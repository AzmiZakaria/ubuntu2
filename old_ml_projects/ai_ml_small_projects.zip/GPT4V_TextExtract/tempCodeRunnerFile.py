response = requests.post('http://localhost:3000/v1/generate', json)
# print(response.status_code)