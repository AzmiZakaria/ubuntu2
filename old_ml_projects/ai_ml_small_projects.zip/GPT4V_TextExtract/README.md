To get it running:

in terminal run: pip install -r requirements. txt

Set API key environment variable: https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety

in terminal run: python GPT4V_DataExtract.py 
