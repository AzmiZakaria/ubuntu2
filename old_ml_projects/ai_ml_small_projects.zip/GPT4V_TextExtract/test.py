import openllm
client=openllm.client.HTTPClient('http://localhost:3000')
response=client.query('explain Blockchain')
print (response)
