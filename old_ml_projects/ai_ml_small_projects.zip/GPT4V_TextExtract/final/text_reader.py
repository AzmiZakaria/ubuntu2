import cv2
import numpy as np
import pytesseract

def preprocess_image(image_path):
    # Load the image using OpenCV
    image = cv2.imread(image_path)
    
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    
    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    # Perform edge detection to find outlines of objects
    edges = cv2.Canny(blurred, 50, 150)
    
    # Find contours in the edged image
    contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Sort contours by area and find the largest contour
    contours = sorted(contours, key=cv2.contourArea, reverse=True)
    largest_contour = contours[0]
    
    # Compute the minimum area bounding rectangle (rotated) of the largest contour
    rect = cv2.minAreaRect(largest_contour)
    box = cv2.boxPoints(rect)
    box = np.int0(box)
    
    # Compute the angle of rotation
    angle = rect[-1]
    
    # Rotate the image to align the text horizontally
    if angle < -45:
        angle = -(90 + angle)
    else:
        angle = -angle
    rotated = cv2.warpAffine(image, cv2.getRotationMatrix2D(tuple(rect[0]), angle, 1.0), (image.shape[1], image.shape[0]), flags=cv2.INTER_CUBIC)
    
    # Apply further preprocessing steps if needed (e.g., thresholding, dilation, erosion)
    # This can depend on the specific characteristics of your images
    
    return rotated

# Example usage
image_path = 'your_image.jpg'
preprocessed_image = preprocess_image(image_path)
cv2.imshow('Preprocessed Image', preprocessed_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
