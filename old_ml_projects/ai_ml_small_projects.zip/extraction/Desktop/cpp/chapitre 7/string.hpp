#include <iostream>
#include <stdexcept>
size_t strlen(const char *str){
    size_t len = 0;
    while (str[len] != '\0'){
        len++;
    }
    return len;
};
int strcmp(const char *str1, const char *str2){
    while (*str1 && *str2 && *str1 == *str2){
        str1++;
        str2++;
    }
    return *str1 - *str2;
};
char *strcpy(char *dest, const char *src){
    char *p = dest;
    while (*src){
        *p++ = *src++;
    }
    *p = '\0';
    return dest;
};
char *strncpy(char *dest, const char *src, size_t count){
    char *p = dest;
    while (count && *src){
        *p++ = *src++;
        count--;
    }
    while (count){
        *p++ = '\0';
        count--;
    }
    return dest;
};
char *strcat(char *dest, const char *src){
    char *p = dest;
    while (*p){
        p++;
    }
    while (*src){
        *p++ = *src++;
    }
    *p = '\0';
    return dest;
};
char *strncat(char *dest, const char *src, size_t count){
    char *p = dest;
    while (*p){
        p++;
    }
    while (count && *src){
        *p++ = *src++;
        count--;
    }
    *p = '\0';
    return dest;
};
const char *strchr(const char *str, int ch){
    while (*str){
        if (*str == ch){
            return str;
        }
        str++;
    }
    return nullptr;
};
char *strchr(char *str, int ch){
    while (*str){
        if (*str == ch){
            return str;
        }
        str++;
    }
    return nullptr;
};
const char *strrchr(const char *str, int ch){
    const char *p = nullptr;
    while (*str){
        if (*str == ch){
            p = str;
        }
        str++;
    }
    return p;
};
char *strrchr(char *str, int ch){
    char *p = nullptr;
    while (*str){
        if (*str == ch){
            p = str;
        }
        str++;
    }
    return p;
};
size_t strspn(const char *str, const char *delim){
    size_t count = 0;
    while (*str && strchr(delim, *str)){
        count++;
        str++;
    }
    return count;
};
size_t strcspn(const char *str, const char *delim){
    size_t count = 0;
    while (*str && !strchr(delim, *str)){
        count++;
        str++;
    }
    return count;
};
const char *strstr(const char *str1, const char *str2){
    while (*str1){
        const char *p = str1;
        const char *q = str2;
        while (*p && *q && *p == *q){
            p++;
            q++;
        }
        if (!*q){
            return str1;
        }
        str1++;
    }
    return nullptr;
};
char *strstr(char *str1, const char *str2){
    while (*str1){
        char *p = str1;
        const char *q = str2;
        while (*p && *q && *p == *q){
            p++;
            q++;
        }
        if (!*q){
            return str1;
        }
        str1++;
    }
    return nullptr;
};
char *strtok(char *str, const char *delim){
    static char *p = nullptr;
    if (str){
        p = str;
    } else if (!p){
        return nullptr;
    }
    str = p + strspn(p, delim);
    p = str + strcspn(str, delim);
    if (p == str){
        return nullptr;
    }
    p = *p ? *p = '\0', p + 1 : nullptr;
    return str;
};
