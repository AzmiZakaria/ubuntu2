#include "string.hpp" 
#include <iostream>
using namespace std;

int main() {
    // Utilize the functions from the "string.hpp" header file here

    // Example usage:
    const char* str = "Hello, World!";
    size_t length = strlen(str);
    cout << "Length of the string: " << length << endl;

    const char* str1 = "Hello";
    const char* str2 = "World";
    int result = strcmp(str1, str2);
    if (result < 0) {
        cout << "str1 is less than str2" << endl;
    } else if (result > 0) {
        cout << "str1 is greater than str2" << endl;
    } else {
        cout << "str1 is equal to str2" << endl;
    }

    char dest[20];
    const char* src = "Copy this";
    strcpy(dest, src);
    cout << "Copied string: " << dest << endl;

    char dest2[20];
    const char* src2 = "Copy this partially";
    strncpy(dest2, src2, 5);
    cout << "Partially copied string: " << dest2 << endl;

    char dest3[20] = "Hello";
    const char* src3 = "World";
    strcat(dest3, src3);
    cout << "Concatenated string: " << dest3 << endl;

    char dest4[20] = "Hello";
    const char* src4 = "World";
    strncat(dest4, src4, 3);
    cout << "Partially concatenated string: " << dest4 << endl;

    const char* str5 = "Hello, World!";
    int ch = 'o';
    const char* firstOccurrence = strchr(str5, ch);
    cout << "First occurrence of '" << ch << "' in the string: " << firstOccurrence << endl;

    char* str6 = "Hello, World!";
    int ch2 = 'o';
    char* lastOccurrence = strrchr(str6, ch2);
    cout << "Last occurrence of '" << ch2 << "' in the string: " << lastOccurrence << endl;

    const char* str7 = "Hello, World!";
    const char* delim = " ,!";
    size_t span = strspn(str7, delim);
    cout << "Length of the initial segment containing only characters from the delimiter set: " << span << endl;

    const char* str8 = "Hello, World!";
    const char* delim2 = " ,!";
    size_t cspan = strcspn(str8, delim2);
    cout << "Length of the initial segment containing no characters from the delimiter set: " << cspan << endl;

    const char* str9 = "Hello, World!";
    const char* substr = "World";
    const char* occurrence = strstr(str9, substr);
    cout << "First occurrence of '" << substr << "' in the string: " << occurrence << endl;

    char str10[20] = "Hello, World!";
    const char* delim3 = " ,!";
    char* token = strtok(str10, delim3);
    while (token != nullptr) {
        cout << "Token: " << token << endl;
        token = strtok(nullptr, delim3);
    }

    return 0;
}