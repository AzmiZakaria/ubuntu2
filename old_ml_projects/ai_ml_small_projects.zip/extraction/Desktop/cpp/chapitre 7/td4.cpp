#include <iostream>
#include <string>
using namespace std;
class Note {
private:
    float value;

public:
    Note(int value) {
        this->value = value;
    }

    

    void input() {
        do {
            cout << "Saisir une note entre 0 et 20 : ";
            cin >> value;
        } while (value < 0 || value > 20);
    }
    void print() const {
        cout << "La note est : " << value << endl;
    }
    void set(float value) {
    this->value = value;
    }
    float get() {
        return value;
    }
    string apprecier() const {
        if (value < 10) {
            return "Insuffisant";
        } else if (value < 12) {
            return "Passable";
        } else if (value < 14) {
            return "Assez bien";
        } else if (value < 16) {
            return "Bien";
        } else if (value < 18) {
            return "Très bien";
        } else {
            return "Excellent";
        }
    }
    void harmonise(Note &note) {
        if (note.get() < 8) {
            note.set(0);
        } else {
            note.set(8);
        }
    }

    float moyenne(Note *notes, int numStudents) {
        float sum = 0;
        for (int i = 0; i < numStudents; i++) {
            sum += notes[i].get();
        }
        return sum / numStudents;
    }

    void appreciation(Note *notes, int numStudents) {
        for (int i = 0; i < numStudents; i++) {
            cout << "Appréciation pour l'élève " << i+1 << " : " << notes[i].apprecier() << endl;
        }
    }
};
int main() {
    // saisie du nombre d'élèves de la classe
    int numStudents;
    cout << "Saisir le nombre d'élèves de la classe : ";
    cin >> numStudents;

    // création du tableau des notes
    Note *notes = new Note[numStudents];

    // boucle de saisie des n notes
    for (int i = 0; i < numStudents; i++) {
        notes[i].input();
    }

    // boucle d’affichage des notes et des appréciations
    for (int i = 0; i < numStudents; i++) {
        notes[i].print();
        cout << "Appréciation pour l'élève " << i+1 << " : " << notes[i].apprecier() << endl;
    }

    // affichage de la moyenne
    float average = moyenne(notes, numStudents);
    cout << "La moyenne est : " << average << endl;

    // boucle sur les notes, si la note est < 15 alors on l'harmonise
    for (int i = 0; i < numStudents; i++) {
        if (notes[i].get() < 15) {
            notes[i].harmonise(notes[i]);
        }
    }

    // affichage de la moyenne après harmonisation
    average = moyenne(notes, numStudents);
    cout << "La moyenne après harmonisation est : " << average << endl;

    // libération de la mémoire
    delete[] notes;

    return 0;
}