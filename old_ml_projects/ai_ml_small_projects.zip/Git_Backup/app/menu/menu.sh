
#!/bin/bash

# Function to display help message
display_help() {
    echo "Usage: $0 [options]"
    echo "Options:"
    echo "  -h,  --help               Display this help message"
    echo "  -g,  --github-connection  Connect to GitHub"
    echo "  -b,  --backup-folder      Backup folder"
    echo "  -sh, --show-github-info   Show GitHub connection status"
    echo "  -ch  --change-folder      Change folder path to backup"
    echo "  -f,  --folder-structure   Manage folder structure"
    echo "  -z,  --zip-folder         Zip the backup folder"
    echo "  -c,  --crypt-folder       Encrypt the zipped folder"
    echo "  -d,  --decrypt-folder     Decrypt the encrypted folder"
    echo "  -t,  -change token        Change the token"
    echo "  -p,  --push-to-github     Push encrypted folder to GitHub"
    echo "  -r,  --rerord_historique  shows the history of the backup"
}

if [[ $# -eq 0 ]]; then
    display_help
    exit 0
fi
# Parse command-line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -h|--help)
            display_help
            exit 0
            ;;
        -g|--github-connection)
            ./github_connection.sh
            ;;
        -b|--backup-folder)
            ./backup_folder.sh
            ;;
        -sh|--show-github-info)
            ./show_github_info.sh
            ;;
        -ch|--change-folder)
            ./change_folder.sh
            ;;
        -f|--folder-structure)
            ./folder_structure.sh
            ;;
        -z|--zip-folder)
            ./zip_folder.sh
            ;;
        -c|--crypt-folder)
            ./crypt_folder.sh
            ;;
        -d|--decrypt-folder)
            ./decrypt_folder.sh
            ;;
        -t|--change-token)
            ./change_token.sh
            ;;
        -p|--push-to-github)
            ./push_to_github.sh
            ;;
        -r|--rerord_historique)
            cat save.log - tail -n 10
            ;; 
        # Add other options and their actions here
        *)
            echo "Error: Unknown option '$1'. Use -h or --help for usage."
            exit 1
            ;;
    esac
    shift
done