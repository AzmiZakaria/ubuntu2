# import cv2
from PIL import Image
# import pytesseract

im_file="data/1.jpg"
im=Image.open(im_file)
print(im)

