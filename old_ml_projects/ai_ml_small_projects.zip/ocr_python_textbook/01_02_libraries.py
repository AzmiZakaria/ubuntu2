import cv2
from PIL import Image
import pytesseract
